#ifndef  __ADC_H
#define  __ADC_H
#include "sys.h"

void Adc_Init(void);
void ADC1_GPIO_Config(void);
void ADC_Config(void);


#endif
