#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class Point {
private:
    double x, y;
public:
    Point() : x(0), y(0) {}
    Point(double xx, double yy) : x(xx), y(yy) {}
    void setX(double xx) { x = xx; }
    void move(double xx, double yy) { x += xx; y += yy; }
    void setY(double yy) { y = yy; }
    double getX() const { return x; }
    double getY() const { return y; }
    void setput(double xx, double yy) { x = xx; y = yy; }
    void inputPoint();
    bool operator==(const Point& p) const;
    void showPoint() const { cout << "�����꣨" << x << "," << y << ")"; }
};

void Point::inputPoint() {
    cout << "������x��y��ֵ��" << endl;
    cin >> x >> y;
}

bool Point::operator==(const Point& p) const {
    return x == p.x && y == p.y;
}

class Circle {
private:
    double radius;
    Point center;
public:
    Circle() : radius(0) {}
    Circle(double x, double y, double r) : center(x, y), radius(r) {}
    void setRadius(double r) { radius = r; }
    double getRadius() const { return radius; }
    void setCenter(const Point& p) { center = p; }
    Point getCenter() const { return center; }
    void setCircle(const Point& p, double r) { center = p; radius = r; }
    void inputCircle() {
        center.inputPoint();
        cout << "������뾶:" << endl;
        cin >> radius;
    }
    void addRadius(double r) { radius += r; }
    double area() const { return 3.14 * radius * radius; }
    void showCircle() const { center.showPoint(); cout << " �뾶��" << radius << "  "; }
};

class Cylinder : public Circle {
private:
    string no;
    string name;
    double height;
public:
    Cylinder() : height(0) {}
    Cylinder(double x, double y, double r, const string& num, const string& nam, double h)
        : Circle(x, y, r), no(num), name(nam), height(h) {}
    void setNo(const string& num) { no = num; }
    void setName(const string& nam) { name = nam; }
    void setHeight(double h) { height = h; }
    string getNo() const { return no; }
    string getName() const { return name; }
    double getHeight() const { return height; }

    void setCylinder(const Point& cent, double r, const string& num, const string& nam, double h) {
        setCenter(cent);
        setRadius(r);
        no = num;
        name = nam;
        height = h;
    }

    void inputCylinder() {
        inputCircle();
        cout << "����Բ���ı�ţ����ֺ͸�" << endl;
        cin >> no >> name >> height;
    }
    void addHeight(double hh) { height += hh; }
    double area() const { return 2 * Circle::area() + 2 * 3.14 * getRadius() * height; }
    double volume() const { return Circle::area() * height; }

    void showCylinder() const {
        showCircle();
        cout << "���:" << no << " ����:" << name << " �ߣ�" << height << endl;
    }

    bool operator==(const Cylinder& cy) const {
        return getCenter() == cy.getCenter();
    }

    bool operator==(const Point& p) const {
        return getCenter() == p;
    }
};

class Manager {
private:
    Cylinder cylinders[100];
    int length;
public:
    Manager() : length(0) {}
    void inputFromFile(const string& filename);
    void outputFile(const string& filename) const;
    void inputFromBinaryFile(const string& filename);
    void outputBinaryFile(const string& filename) const;
    void traverseCylinder() const;
    void traverseCylinderIndex(int idx) const;
    void printArea() const;
    void printVolume() const;
    void insertCylinder(const Cylinder& cy);
    bool searchCylinder(const Cylinder& cy) const;
    bool searchCylinder(const Point& p) const;
    int searchCylinderIndex(const Cylinder& cy) const;
    int searchCylinderIndex(const Point& p) const;
    void modifyCylinder(const Cylinder& cy);
    void deleteCylinder(const Cylinder& cy);
    void deleteAllCylinders();
};

void Manager::inputFromFile(const string& filename) {
    ifstream infile(filename.c_str(), ios::in);
    if (!infile) {
        cerr << "�ļ��򿪴���!" << endl;
        return;
    }
    double xx, yy, rr, hh;
    string num, nam;
    int i = 0;
    while (infile >> xx >> yy >> rr >> num >> nam >> hh) {
        cylinders[i].setCylinder(Point(xx, yy), rr, num, nam, hh);
        i++;
    }
    length = i;
    infile.close();
}

void Manager::outputFile(const string& filename) const {
    ofstream outfile(filename.c_str(), ios::out);
    if (!outfile) {
        cerr << "�ļ��򿪴���!" << endl;
        return;
    }
    for (int i = 0; i < length; i++) {
        outfile << cylinders[i].getCenter().getX() << " "
                << cylinders[i].getCenter().getY() << " "
                << cylinders[i].getRadius() << " "
                << cylinders[i].getNo() << " "
                << cylinders[i].getName() << " "
                << cylinders[i].getHeight() << endl;
    }
    outfile.close();
}

void Manager::inputFromBinaryFile(const string& filename) {
    ifstream infile(filename.c_str(), ios::binary);
    if (!infile) {
        cerr << "�ļ��򿪴���!" << endl;
        return;
    }
    infile.read(reinterpret_cast<char*>(cylinders), sizeof(Cylinder) * 100);
    length = static_cast<int>(infile.gcount()) / static_cast<int>(sizeof(Cylinder));
    infile.close();
}

void Manager::outputBinaryFile(const string& filename) const {
    ofstream outfile(filename.c_str(), ios::binary);
    if (!outfile) {
        cerr << "�ļ��򿪴���!" << endl;
        return;
    }
    outfile.write(reinterpret_cast<const char*>(cylinders), sizeof(Cylinder) * length);
    outfile.close();
}

void Manager::traverseCylinder() const {
    for (int i = 0; i < length; i++) {
        cout << "��ţ�" << i + 1 << " ";
        cylinders[i].showCylinder();
    }
}

void Manager::traverseCylinderIndex(int idx) const {
    if (idx >= 0 && idx < length) {
        cout << "��ţ�" << idx + 1 << ": ";
        cylinders[idx].showCylinder();
    } else {
        cout << "�����Ч!" << endl;
    }
}

void Manager::printArea() const {
    for (int i = 0; i < length; i++) {
        cout << "��ţ�" << i + 1 << " ���: " << cylinders[i].area() << endl;
    }
}

void Manager::printVolume() const {
    for (int i = 0; i < length; i++) {
        cout << "��ţ�" << i + 1 << " ���: " << cylinders[i].volume() << endl;
    }
}

void Manager::insertCylinder(const Cylinder& cy) {
    if (length < 100) {
        cylinders[length++] = cy;
    } else {
        cout << "Բ�������������޷�������Բ��!" << endl;
    }
}

bool Manager::searchCylinder(const Cylinder& cy) const {
    for (int i = 0; i < length; i++) {
        if (cylinders[i] == cy) return true;
    }
    return false;
}

bool Manager::searchCylinder(const Point& p) const {
    for (int i = 0; i < length; i++) {
        if (cylinders[i].getCenter() == p) return true;
    }
    return false;
}

int Manager::searchCylinderIndex(const Cylinder& cy) const {
    for (int i = 0; i < length; i++) {
        if (cylinders[i] == cy) return i;
    }
    return -1;
}

int Manager::searchCylinderIndex(const Point& p) const {
    for (int i = 0; i < length; i++) {
        if (cylinders[i].getCenter() == p) return i;
    }
    return -1;
}

void Manager::modifyCylinder(const Cylinder& cy) {
    int index = searchCylinderIndex(cy);
    if (index != -1) {
        double newRadius, newHeight;
        string newNo, newName;
        cout << "�����µİ뾶���߶ȡ���ź����֣�" << endl;
        cin >> newRadius >> newHeight >> newNo >> newName;
        cylinders[index].setRadius(newRadius);
        cylinders[index].setHeight(newHeight);
        cylinders[index].setNo(newNo);
        cylinders[index].setName(newName);
    } else {
        cout << "�Ҳ���Բ��!" << endl;
    }
}

void Manager::deleteCylinder(const Cylinder& cy) {
    int index = searchCylinderIndex(cy);
    if (index != -1) {
        for (int i = index; i < length - 1; i++) {
            cylinders[i] = cylinders[i + 1];
        }
        length--;
    } else {
        cout << "�Ҳ���Բ��!" << endl;
    }
}

void Manager::deleteAllCylinders() {
    length = 0;
    cout << "����Բ����ɾ��!" << endl;
}

void menu() {
    cout << endl << endl
         << "*----------�����˵�----------*" << endl
         << "*                            *" << endl
         << "*  1. ���ļ���ȡԲ������     *" << endl
         << "*  2. ����Բ�����ݵ��ļ�     *" << endl
         << "*  3. ��ʾ����Բ����Ϣ       *" << endl
         << "*  4. ����Բ��λ��           *" << endl
         << "*  5. ������Բ��             *" << endl
         << "*  6. �޸�Բ����Ϣ           *" << endl
         << "*  7. ɾ��ָ��Բ��           *" << endl
         << "*  8. ɾ������Բ��           *" << endl
         << "*  9. ��ʾ����Բ�����       *" << endl
         << "* 10. ��ʾ����Բ�����       *" << endl
         << "* 11. �˳�                   *" << endl
         << "*----------------------------*" << endl;
}

int main() {
    Cylinder cy;
    Manager manager;
    int choose;
    string filename;
    int idx;
    Point p;

    while (1) {
        menu();
        cout << "��ѡ����Ĳ������������֣���";
        cin >> choose;
        switch (choose) {
        case 1:
            cout << "�������ļ�·��: ";
            cin >> filename;
            manager.inputFromFile(filename);
            break;
        case 2:
            cout << "�������ļ�·��: ";
            cin >> filename;
            manager.outputFile(filename);
            break;
        case 3:
            manager.traverseCylinder();
            break;
        case 4:
            cout << "������Ҫ���ҵĵ�����:" << endl;
            p.inputPoint();
            idx = manager.searchCylinderIndex(p);
            if (idx != -1) {
                cout << "���ҳɹ�" << endl;
                manager.traverseCylinderIndex(idx);
            } else {
                cout << "���Ҳ��ɹ�" << endl;
            }
            break;
        case 5:
            p.inputPoint();
            if (!manager.searchCylinder(p)) {
                cy.inputCylinder();
                manager.insertCylinder(cy);
            } else {
                cout << "�ڸ�����λ���Ѿ���Բ�������ܲ��롣" << endl;
            }
            break;
        case 6:
            cy.inputCylinder();
            manager.modifyCylinder(cy);
            break;
        case 7:
            cy.inputCylinder();
            manager.deleteCylinder(cy);
            break;
        case 8:
            manager.deleteAllCylinders();
            break;
        case 9:
            manager.printArea();
            break;
        case 10:
            manager.printVolume();
            break;
        case 11:
            exit(0);
        default:
            cout << "��Чѡ��!" << endl;
            break;
        }
    }

    return 0;
}