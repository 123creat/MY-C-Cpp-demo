#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PATIENTS 100       // ���������
#define NAME_LENGTH 50         // ������󳤶�
#define DATE_LENGTH 20         // ������󳤶�

// ���岡�˽ṹ��
typedef struct {
    int id;                            // ���˱��
    char name[NAME_LENGTH];            // ��������
    char gender;                       // �Ա� ('M' �� 'F')
    int age;                           // ����
    char admissionDate[DATE_LENGTH];   // ��Ժʱ��
} Patient;

Patient patients[MAX_PATIENTS];  // ��������
int patientCount = 0;            // ��ǰ��������

// ���Ӳ�����Ϣ
void addPatient() {
    if (patientCount >= MAX_PATIENTS) {
        printf("Patient list is full.\n");
        return;
    }
    
    Patient p;
    p.id = patientCount + 1;  // �Զ����ɲ��˱��

    printf("Enter name: ");
    scanf("%s", p.name);
    printf("Enter gender (M/F): ");
    scanf(" %c", &p.gender);
    printf("Enter age: ");
    scanf("%d", &p.age);
    printf("Enter admission date (YYYY-MM-DD): ");
    scanf("%s", p.admissionDate);

    patients[patientCount++] = p;  // ���������ӵ�������
    printf("Patient added successfully.\n");
}

// ��ʾ����������Ϣ
void displayPatient(Patient p) {
    printf("ID: %d\n", p.id);
    printf("Name: %s\n", p.name);
    printf("Gender: %c\n", p.gender);
    printf("Age: %d\n", p.age);
    printf("Admission Date: %s\n", p.admissionDate);
}

// ��ʾ���в�����Ϣ
void displayPatients() {
    for (int i = 0; i < patientCount; i++) {
        displayPatient(patients[i]);
        printf("\n");
    }
}

// ���²�����Ϣ
void updatePatient() {
    int id;
    printf("Enter patient ID to update: ");
    scanf("%d", &id);

    if (id <= 0 || id > patientCount) {
        printf("Invalid patient ID.\n");
        return;
    }

    Patient *p = &patients[id - 1];

    printf("Enter new name: ");
    scanf("%s", p->name);
    printf("Enter new gender (M/F): ");
    scanf(" %c", &p->gender);
    printf("Enter new age: ");
    scanf("%d", &p->age);
    printf("Enter new admission date (YYYY-MM-DD): ");
    scanf("%s", p->admissionDate);

    printf("Patient updated successfully.\n");
}

// ɾ��������Ϣ
void deletePatient() {
    int id;
    printf("Enter patient ID to delete: ");
    scanf("%d", &id);

    if (id <= 0 || id > patientCount) {
        printf("Invalid patient ID.\n");
        return;
    }

    for (int i = id - 1; i < patientCount - 1; i++) {
        patients[i] = patients[i + 1];  // ������������Ϣ��ǰ�ƶ�
    }
    patientCount--;

    printf("Patient deleted successfully.\n");
}

// ����������������Ϣ
void sortPatientsByName() {
    for (int i = 0; i < patientCount - 1; i++) {
        for (int j = i + 1; j < patientCount; j++) {
            if (strcmp(patients[i].name, patients[j].name) > 0) {
                Patient temp = patients[i];
                patients[i] = patients[j];
                patients[j] = temp;
            }
        }
    }
    printf("Patients sorted by name.\n");
}

// �������ֲ��Ҳ�����Ϣ
void searchPatientByName() {
    char name[NAME_LENGTH];
    printf("Enter name to search: ");
    scanf("%s", name);

    for (int i = 0; i < patientCount; i++) {
        if (strcmp(patients[i].name, name) == 0) {
            displayPatient(patients[i]);
            return;
        }
    }
    printf("Patient not found.\n");
}

// ��ʾ�˵�
void menu() {
    printf("Patient Management System\n");
    printf("1. Add Patient\n");
    printf("2. Display Patients\n");
    printf("3. Update Patient\n");
    printf("4. Delete Patient\n");
    printf("5. Sort Patients by Name\n");
    printf("6. Search Patient by Name\n");
    printf("7. Exit\n");
}

// ������
int main() {
    int choice;
    while (1) {
        menu();
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addPatient();
                break;
            case 2:
                displayPatients();
                break;
            case 3:
                updatePatient();
                break;
            case 4:
                deletePatient();
                break;
            case 5:
                sortPatientsByName();
                break;
            case 6:
                searchPatientByName();
                break;
            case 7:
                printf("Exiting the system.\n");
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}