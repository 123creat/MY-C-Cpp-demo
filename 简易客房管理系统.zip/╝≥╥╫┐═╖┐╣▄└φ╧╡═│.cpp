#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <ctime>
#include <algorithm>

// 定义枚举类型 RoomType
enum RoomType { ECONOMY, STANDARD, DELUXE, SINGLE, DOUBLE, TRIPLE };

// 员工类
class Employee {
public:
    std::string name;             // 员工姓名
    std::string position;         // 职位
    std::vector<int> managedRooms; // 管理的房间

    // Employee 类的构造函数
    Employee(const std::string& name, const std::string& position)
        : name(name), position(position) {}

    // 添加员工管理的房间
    void addManagedRoom(int roomNumber) {
        managedRooms.push_back(roomNumber);
    }
};

// 房间类
class Room {
public:
    int roomNumber;              // 房间号
    RoomType type;               // 房间类型
    bool isOccupied;             // 是否被占用
    std::string guestName;       // 客人姓名
    std::tm checkInTime;         // 入住时间
    int stayDuration;            // 入住天数
    int deposit;                 // 押金
    int dailyRate;               // 房价
    int totalCharge;             // 总花费

    // 默认构造函数
    Room() : roomNumber(0), type(ECONOMY), isOccupied(false), dailyRate(0), totalCharge(0) {}

    // Room 类的构造函数
    Room(int roomNumber, RoomType type, int dailyRate)
        : roomNumber(roomNumber), type(type), isOccupied(false), dailyRate(dailyRate), totalCharge(0) {}

    // 登记入住
    void checkIn(const std::string& guestName, const std::tm& checkInTime, int stayDuration, int deposit) {
        this->guestName = guestName;
        this->checkInTime = checkInTime;
        this->stayDuration = stayDuration;
        this->deposit = deposit;
        this->isOccupied = true;
        this->totalCharge = stayDuration * dailyRate; // 计算总花费
        std::cout << "Guest " << guestName << " successfully checked into room " << roomNumber << "." << std::endl;
    }

    // 退房
    void checkOut() {
        this->isOccupied = false;
        this->guestName = "";
        this->stayDuration = 0;
        this->deposit = 0;
        this->totalCharge = 0;
    }

    // 增加押金
    void addDeposit(int amount) {
        deposit += amount;
    }

    // 显示结算信息
    void displaySettlement() {
        std::cout << "Guest Name: " << guestName << std::endl;
        std::cout << "Room Number: " << roomNumber << std::endl;
        std::cout << "Total Charge: " << totalCharge << std::endl;
        std::cout << "Deposit: " << deposit << std::endl;
        std::cout << "Balance: " << (deposit - totalCharge) << std::endl;
    }
};

// 酒店管理系统类
class HotelManagementSystem {
public:
    std::map<int, Room> rooms;       // 存储房间信息
    std::vector<Employee> employees; // 存储员工信息

    // 添加房间
    void addRoom(int roomNumber, RoomType type, int dailyRate) {
        rooms[roomNumber] = Room(roomNumber, type, dailyRate);
    }

    // 添加员工
    void addEmployee(const std::string& name, const std::string& position) {
        employees.emplace_back(name, position);
    }

    // 为员工分配房间
    void assignRoomsToEmployee(const std::string& employeeName, const std::vector<int>& roomNumbers) {
        for (auto& emp : employees) {
            if (emp.name == employeeName) {
                for (int roomNumber : roomNumbers) {
                    emp.addManagedRoom(roomNumber);
                }
                std::cout << "Rooms assigned to " << employeeName << std::endl;
                return;
            }
        }
        std::cout << "Employee not found." << std::endl;
    }

    // 登记客人入住
    void registerGuest(int roomNumber, const std::string& guestName, const std::tm& checkInTime, int stayDuration, int deposit, RoomType type) {
        if (rooms.find(roomNumber) != rooms.end()) {
            Room& room = rooms[roomNumber];
            if (!room.isOccupied && room.type == type) {
                room.checkIn(guestName, checkInTime, stayDuration, deposit);
            } else {
                std::cout << "Room is either occupied or type mismatch." << std::endl;
            }
        } else {
            std::cout << "Room not found." << std::endl;
        }
    }

    // 显示员工管理的房间信息
    void displayRoomInfoByEmployee(const std::string& employeeName) {
        for (const auto& emp : employees) {
            if (emp.name == employeeName) {
                std::cout << emp.name << "'s managed rooms:" << std::endl;
                for (int roomNumber : emp.managedRooms) {
                    auto it = rooms.find(roomNumber);
                    if (it != rooms.end()) {
                        std::cout << "Room " << roomNumber << ": ";
                        if (it->second.isOccupied) {
                            std::cout << "Occupied by " << it->second.guestName;
                        } else {
                            std::cout << "Vacant";
                        }
                        std::cout << std::endl;
                    } else {
                        std::cout << "Room " << roomNumber << " not found in the system." << std::endl;
                    }
                }
                return;
            }
        }
        std::cout << "Employee not found." << std::endl;
    }

    // 显示指定客人的信息
    void displayGuestInfo(const std::string& guestName) {
        for (auto& room : rooms) {
            if (room.second.isOccupied && room.second.guestName == guestName) {
                room.second.displaySettlement();
                return;
            }
        }
        std::cout << "Guest " << guestName << " not found." << std::endl;
    }

    // 修改房间的押金
    void modifyDeposit(int roomNumber, int amount) {
        if (rooms.find(roomNumber) != rooms.end()) {
            rooms[roomNumber].addDeposit(amount);
            std::cout << "Deposit for room " << roomNumber << " updated." << std::endl;
        } else {
            std::cout << "Room " << roomNumber << " not found." << std::endl;
        }
    }

    // 按照房间类型排序
    void sortRoomsByType() {
        std::map<RoomType, int> roomCounts;
        for (const auto& room : rooms) {
            if (room.second.isOccupied) {
                roomCounts[room.second.type]++;
            }
        }

        std::vector<std::pair<RoomType, int>> sortedRoomCounts(roomCounts.begin(), roomCounts.end());
        std::sort(sortedRoomCounts.begin(), sortedRoomCounts.end(), [](const std::pair<RoomType, int>& a, const std::pair<RoomType, int>& b) {
            return a.second > b.second;
        });

        std::cout << "Rooms sorted by occupancy:" << std::endl;
        for (const auto& count : sortedRoomCounts) {
            std::string type;
            switch (count.first) {
                case ECONOMY: type = "Economy"; break;
                case STANDARD: type = "Standard"; break;
                case DELUXE: type = "Deluxe"; break;
                case SINGLE: type = "Single"; break;
                case DOUBLE: type = "Double"; break;
                case TRIPLE: type = "Triple"; break;
            }
            std::cout << type << " Rooms: " << count.second << std::endl;
        }
    }

    // 显示可用房间
    void displayAvailableRooms() {
        std::map<RoomType, int> availableRooms;
        for (const auto& room : rooms) {
            if (!room.second.isOccupied) {
                availableRooms[room.second.type]++;
            }
        }

        std::cout << "Available rooms:" << std::endl;
        for (const auto& count : availableRooms) {
            std::string type;
            switch (count.first) {
                case ECONOMY: type = "Economy"; break;
                case STANDARD: type = "Standard"; break;
                case DELUXE: type = "Deluxe"; break;
                case SINGLE: type = "Single"; break;
                case DOUBLE: type = "Double"; break;
                case TRIPLE: type = "Triple"; break;
            }
            std::cout << type << " Rooms: " << count.second << std::endl;
        }
    }

    // 取消预订
    void cancelReservation(int roomNumber) {
        if (rooms.find(roomNumber) != rooms.end()) {
            if (rooms[roomNumber].isOccupied) {
                rooms[roomNumber].checkOut();
                std::cout << "Reservation for room " << roomNumber << " has been cancelled." << std::endl;
            } else {
                std::cout << "Room " << roomNumber << " is not currently occupied." << std::endl;
            }
        } else {
            std::cout << "Room " << roomNumber << " not found." << std::endl;
        }
    }

    // 更新员工信息
    void updateEmployee(const std::string& originalName, const std::string& newName, const std::string& newPosition) {
        for (auto& emp : employees) {
            if (emp.name == originalName) {
                emp.name = newName;
                emp.position = newPosition;
                std::cout << "Employee details updated." << std::endl;
                return;
            }
        }
        std::cout << "Employee not found." << std::endl;
    }
};

// 获取当前时间
std::tm getCurrentTime() {
    std::time_t t = std::time(nullptr);
    return *std::localtime(&t);
}

int main() {
    // 创建酒店管理系统对象
    HotelManagementSystem system;

    // 初始化房间和员工
    system.addRoom(101, STANDARD, 100);
    system.addRoom(102, DELUXE, 200);
    system.addRoom(103, ECONOMY, 50);
    system.addRoom(104, SINGLE, 80);
    system.addRoom(105, DOUBLE, 150);
    system.addEmployee("John", "Floor Manager");
    system.addEmployee("Jane", "Housekeeping");

    // 为员工分配房间
    system.assignRoomsToEmployee("John", {101, 102, 103, 104, 105});

    int choice;
    do {
        // 显示菜单选项
        std::cout << "\nPlease choose an option:" << std::endl;
        std::cout << "1. Register Guest" << std::endl;
        std::cout << "2. Display Room Info by Employee" << std::endl;
        std::cout << "3. Display Guest Info" << std::endl;
        std::cout << "4. Modify Deposit" << std::endl;
        std::cout << "5. Sort Rooms by Type" << std::endl;
        std::cout << "6. Display Available Rooms" << std::endl;
        std::cout << "7. Cancel Reservation" << std::endl;
        std::cout << "8. Update Employee Info" << std::endl;
        std::cout << "9. Add New Room" << std::endl;
        std::cout << "10. Add New Employee" << std::endl;
        std::cout << "11. Exit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: { // 登记客人入住
                int roomNumber;
                std::string guestName;
                std::tm checkInTime = getCurrentTime();
                int stayDuration;
                int deposit;
                RoomType roomType;

                // 输入房间号
                std::cout << "Enter room number: ";
                std::cin >> roomNumber;

                // 输入客人姓名
                std::cout << "Enter guest name: ";
                std::cin.ignore(); // 忽略换行符
                std::getline(std::cin, guestName);

                // 输入入住期限
                std::cout << "Enter stay duration (days): ";
                std::cin >> stayDuration;

                // 输入押金
                std::cout << "Enter deposit: ";
                std::cin >> deposit;

                // 输入房间类型（通过菜单选择）
                bool typeSelected = false;
                while (!typeSelected) {
                    std::cout << "Select room type:" << std::endl;
                    std::cout << "0. Economy" << std::endl;
                    std::cout << "1. Standard" << std::endl;
                    std::cout << "2. Deluxe" << std::endl;
                    std::cout << "3. Single" << std::endl;
                    std::cout << "4. Double" << std::endl;
                    std::cout << "5. Triple" << std::endl;
                    std::cout << "Enter choice: ";
                    int typeChoice;
                    std::cin >> typeChoice;
                    switch (typeChoice) {
                        case 0: roomType = ECONOMY; typeSelected = true; break;
                        case 1: roomType = STANDARD; typeSelected = true; break;
                        case 2: roomType = DELUXE; typeSelected = true; break;
                        case 3: roomType = SINGLE; typeSelected = true; break;
                        case 4: roomType = DOUBLE; typeSelected = true; break;
                        case 5: roomType = TRIPLE; typeSelected = true; break;
                        default: std::cout << "Invalid choice. Please try again." << std::endl;
                    }
                }

                // 检查房间是否可用且类型匹配
                system.registerGuest(roomNumber, guestName, checkInTime, stayDuration, deposit, roomType);
                break;
            }
            case 2: { // 显示员工管理的房间信息
                std::string employeeName;
                std::cout << "Enter employee name: ";
                std::cin.ignore(); // 忽略换行符
                std::getline(std::cin, employeeName);
                system.displayRoomInfoByEmployee(employeeName);
                break;
            }
            case 3: { // 显示客人信息
                std::string guestName;
                std::cout << "Enter guest name: ";
                std::cin.ignore(); // 忽略换行符
                std::getline(std::cin, guestName);
                system.displayGuestInfo(guestName);
                break;
            }
            case 4: { // 修改押金
                int roomNumber;
                int amount;
                std::cout << "Enter room number: ";
                std::cin >> roomNumber;
                std::cout << "Enter deposit amount to add: ";
                std::cin >> amount;
                system.modifyDeposit(roomNumber, amount);
                break;
            }
            case 5: // 按房间类型排序
                system.sortRoomsByType();
                break;
            case 6: // 显示可用房间
                system.displayAvailableRooms();
                break;
            case 7: { // 取消预订
                int roomNumber;
                std::cout << "Enter room number for cancellation: ";
                std::cin >> roomNumber;
                system.cancelReservation(roomNumber);
                break;
            }
            case 8: { // 更新员工信息
                std::string originalName;
                std::string newName;
                std::string newPosition;

                std::cout << "Enter original employee name: ";
                std::cin.ignore(); // 忽略换行符
                std::getline(std::cin, originalName);

                std::cout << "Enter new employee name: ";
                std::getline(std::cin, newName);

                std::cout << "Enter new employee position: ";
                std::getline(std::cin, newPosition);

                system.updateEmployee(originalName, newName, newPosition);
                break;
            }
            case 9: { // 添加新房间
                int roomNumber;
                RoomType roomType;
                int dailyRate;

                // 输入房间号
                std::cout << "Enter room number: ";
                std::cin >> roomNumber;

                // 输入房价
                std::cout << "Enter daily rate: ";
                std::cin >> dailyRate;

                // 输入房间类型（通过菜单选择）
                bool typeSelected = false;
                while (!typeSelected) {
                    std::cout << "Select room type:" << std::endl;
                    std::cout << "0. Economy" << std::endl;
                    std::cout << "1. Standard" << std::endl;
                    std::cout << "2. Deluxe" << std::endl;
                    std::cout << "3. Single" << std::endl;
                    std::cout << "4. Double" << std::endl;
                    std::cout << "5. Triple" << std::endl;
                    std::cout << "Enter choice: ";
                    int typeChoice;
                    std::cin >> typeChoice;
                    switch (typeChoice) {
                        case 0: roomType = ECONOMY; typeSelected = true; break;
                        case 1: roomType = STANDARD; typeSelected = true; break;
                        case 2: roomType = DELUXE; typeSelected = true; break;
                        case 3: roomType = SINGLE; typeSelected = true; break;
                        case 4: roomType = DOUBLE; typeSelected = true; break;
                        case 5: roomType = TRIPLE; typeSelected = true; break;
                        default: std::cout << "Invalid choice. Please try again." << std::endl;
                    }
                }

                // 添加房间
                system.addRoom(roomNumber, roomType, dailyRate);
                std::cout << "Room " << roomNumber << " added successfully." << std::endl;
                break;
            }
            case 10: { // 添加新员工
                std::string name;
                std::string position;

                std::cout << "Enter new employee name: ";
                std::cin.ignore(); // 忽略换行符
                std::getline(std::cin, name);

                std::cout << "Enter new职位：";
                std::getline(std::cin, position);

                system.addEmployee(name, position);
                std::cout << "Employee " << name << " added successfully." << std::endl;
                break;
            }
            case 11:
                std::cout << "Exiting system. Goodbye!" << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 11);

return 0;
}
