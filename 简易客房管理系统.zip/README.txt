这是一个简易客房管理系统，用户可以通过以下步骤进行操作：

编译和运行程序：

将代码保存为一个 .cpp 文件，例如 HotelManagementSystem.cpp。
使用 C++ 编译器编译，例如使用 g++ 编译：
g++ -o HotelManagementSystem HotelManagementSystem.cpp
运行生成的可执行文件：
./HotelManagementSystem
操作步骤：

程序启动后，会显示一个菜单选项列表，用户可以选择相应的操作。
根据提示输入相应的信息，如房间号、客人姓名、入住天数、押金等。
根据用户的选择，程序会执行相应的功能，如登记客人入住、显示信息、修改押金等。
用户可以反复选择不同的操作，直到选择退出选项。
操作示例
添加房间：

在菜单中选择 "9. Add New Room" 选项，输入房间号、房价和房间类型，即可添加新房间。
例如：
Enter room number: 106
Enter daily rate: 120
Select room type:
0. Economy
1. Standard
2. Deluxe
3. Single
4. Double
5. Triple
Enter choice: 1
Room 106 added successfully.
添加员工：

在菜单中选择 "10. Add New Employee" 选项，输入员工姓名和职位，即可添加新员工。
例如：
Enter new employee name: Alice
Enter new职位：Receptionist
Employee Alice added successfully.
登记客人入住：

在菜单中选择 "1. Register Guest" 选项，输入房间号、客人姓名、入住天数、押金和房间类型，即可登记客人入住。
例如：
Enter room number: 106
Enter guest name: Bob
Enter stay duration (days): 3
Enter deposit: 300
Select room type:
0. Economy
1. Standard
2. Deluxe
3. Single
4. Double
5. Triple
Enter choice: 1
Guest Bob successfully checked into room 106.
显示员工管理的房间信息：

在菜单中选择 "2. Display Room Info by Employee" 选项，输入员工姓名，即可显示该员工管理的所有房间信息。
例如：
Enter employee name: John
John's managed rooms:
Room 101: Vacant
Room 102: Vacant
Room 103: Vacant
Room 104: Vacant
Room 105: Vacant
显示客人信息：

在菜单中选择 "3. Display Guest Info" 选项，输入客人姓名，即可显示该客人的信息。
例如：
Enter guest name: Bob
Guest Name: Bob
Room Number: 106
Total Charge: 360
Deposit: 300
Balance: -60
修改房间押金：

在菜单中选择 "4. Modify Deposit" 选项，输入房间号和需要增加的押金金额，即可修改房间押金。
例如：
Enter room number: 106
Enter deposit amount to add: 100
Deposit for room 106 updated.
按房间类型排序：

在菜单中选择 "5. Sort Rooms by Type" 选项，即可按房间类型排序并显示。
例如：
Rooms sorted by occupancy:
Standard Rooms: 1
显示可用房间：

在菜单中选择 "6. Display Available Rooms" 选项，即可显示所有可用房间。
例如：
Available rooms:
Economy Rooms: 1
Standard Rooms: 1
Deluxe Rooms: 1
Single Rooms: 1
Double Rooms: 1
取消预订：

在菜单中选择 "7. Cancel Reservation" 选项，输入房间号，即可取消该房间的预订。
例如：
Enter room number for cancellation: 106
Reservation for room 106 has been cancelled.
更新员工信息：

在菜单中选择 "8. Update Employee Info" 选项，输入原始员工姓名、新员工姓名和新职位，即可更新员工信息。
例如：
Enter original employee name: John
Enter new employee name: John Smith
Enter new employee position: General Manager
Employee details updated.
通过上述操作，用户可以有效地管理酒店的房间和员工，处理客人入住和退房等事务。